﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Microsoft.Win32;

namespace IServ_Uploader.installer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            button1.Enabled = false;
            string Iserv = url.Text;
            string username = user.Text;
            string password = pwd.Text;

            string[] data = new string[] { Iserv, username, password };
            File.WriteAllLines(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)+@"\meta-data.txt",data);
            WebClient client = new WebClient();
            client.DownloadFile("http://felix.vossel.gymnasium-melle.org/iservup.exe",Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)+@"\iservup.exe");
            client.DownloadFile("http://felix.vossel.gymnasium-melle.org/WebDAV.dll", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\WebDAV.dll");

            RegistryKey key;
            key = Registry.ClassesRoot.OpenSubKey("*\\shell", true);
            RegistryKey key2 = key.CreateSubKey("Upload to IServ");
            key2.SetValue("icon", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\iservup.exe,0");
            RegistryKey key3 = key2.CreateSubKey("Command");
            key3.SetValue("", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\iservup.exe %1");
            key3.Close();
            key2.Close();
            key.Close();

            RegistryKey key1;
            key1 = Registry.ClassesRoot.OpenSubKey("Directory\\shell", true);
            RegistryKey key21 = key1.CreateSubKey("Upload to IServ");
            key21.SetValue("icon", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\iservup.exe,0");
            RegistryKey key31 = key21.CreateSubKey("Command");
            key31.SetValue("", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\iservup.exe %1");
            key31.Close();
            key21.Close();
            key1.Close();
            MessageBox.Show("Die Installation wurde erfolgreich abgeschlossen, Sie können den IservUploader benutzen, in dem sie einen Rechtsklick auf eine Datei machen und dann auf \"iservup\" klicken.\n" +
                "Die hochgeladenen Dateien werden in dem Ordner IservUpload gespeichert.","Erfolgreich");
            Close();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://felix.vossel.gymnasium-melle.org/software.html");
        }
    }
}
