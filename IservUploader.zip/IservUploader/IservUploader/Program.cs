﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.IO;
using WebDAV;

namespace ConsoleApp15
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] data = File.ReadAllLines(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\meta-data.txt");

            WebDAVClientCredential credential = new WebDAVClientCredential(data.ElementAt(1),data.ElementAt(2));
            WebDAVClient client = new WebDAVClient(credential);
            try
            {
                client.Mkcol(data.ElementAt(0) + "/webdav/Files/IservUpload");
            }

            catch (Exception)
            {

            }
            hier:
            try
            {
                string endung = args[0].Substring(args[0].LastIndexOf(@"\") + 1);

                client.Put(data.ElementAt(0) + "/webdav/Files/IservUpload/" + endung, File.ReadAllBytes(args[0]));
                MessageBox.Show("Die Datei: \""+args[0]+"\" wurde erfolgreich auf ihren IServ-Server hochgeladen.","Hochladen erfolgreich",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }

            catch(Exception)
            {
                if (MessageBox.Show("Unerwarteter Fehler beim Hochladen der Datei: \""+args[0]+"\"!\n" +"Wollen Sie es erneut versuchen?","Fehler",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error)==DialogResult.Retry)
                {
                    goto hier;
                }
            }
            

            
        }
    }
}
